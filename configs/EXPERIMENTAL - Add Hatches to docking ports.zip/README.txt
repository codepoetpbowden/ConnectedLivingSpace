Adding Hatches to docking ports
-------------------------------

Connected Living Space provides a feature that modifies the stock docking ports in the game to have hatches in them. If this feature is install incorrectly IT CAN BREAK YOUR SAVE. It is suggested that this feature is used with caution, and that save files are backed up before it feature is used.

Installation:
-------------

1) Modify your save file "persistent.sfs", and do a search and replace in order to replace all instances of "name = ModuelDockingNode" with "name = ModuleDockingNodeHatch"
2) copy the enclosed file CLSAddHatchesToDockingNodes.cfg to the GameData\ConnectedLivingSpace\Plugins directory.

Uninstallation:
---------------

1) Modify your save file "persistent.sfs", and do a search and replace in order to replace all instances of "name = ModuelDockingNodeHatch" with "name = ModuleDockingNode"
2) delete the file CLSAddHatchesToDockingNodes.cfg to the GameData\ConnectedLivingSpace\Plugins directory.

If you have multiple save files then you will need to modify each one. This is a bit of a bore I know, and perhaps in time a better solution will emerge. For now this feature is not enabled by default, and you will not loose much by not using it.

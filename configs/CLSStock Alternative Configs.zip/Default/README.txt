Default Stock config for CLS
--------------------------

The Default Stock config for CLS allows for parts to be passable based on an interpretation of the function of the part (ie "that capsule is supposed to have a heatsheild onthe bottom, I will make it impassable")
If you want the default config in CLS then copy this config file over to the plugin directory. Note this is the version that is set up by default.
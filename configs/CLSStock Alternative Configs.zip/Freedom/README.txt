Freedom Stock config for CLS
--------------------------

The Freedom Stock config for CLS allows for more parts to be passable based on an interpretation of the textures (ie "that looks a bit like a hatch, I will make the node passable)
If you want more freedom in CLS then copy this config file over the default CLSStock.cfg